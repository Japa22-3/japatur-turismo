const burger = document.getElementById('burger');
const navLinks = document.getElementById('navLinks');
if (burger && navLinks) {
  burger.addEventListener('click', () => navLinks.classList.toggle('open'));
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => navLinks.classList.remove('open'));
  });
}

const form = document.getElementById('contactForm');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nome = document.getElementById('nome').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const servico = document.getElementById('servico').value.trim();
    const mensagem = document.getElementById('mensagem').value.trim();

    const texto = `Olá! Vim pelo site da Japatur.

Nome: ${nome}
Telefone: ${telefone}
Serviço: ${servico}
Detalhes: ${mensagem || 'Não informado'}

Gostaria de um orçamento.`;
    const url = `https://wa.me/5515997457878?text=${encodeURIComponent(texto)}`;
    window.open(url, '_blank');
    form.reset();
  });
}
