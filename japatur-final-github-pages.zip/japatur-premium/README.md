# Japatur Turismo e Fretamentos — Versão final

## Arquivos inclusos
- index.html
- 404.html
- .nojekyll
- robots.txt
- css/style.css
- js/main.js
- images/*

## Como colocar no ar no GitHub Pages
1. Crie ou abra o repositório `japatur-turismo`.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Vá em **Settings > Pages**.
4. Em **Source**, selecione **Deploy from a branch**.
5. Escolha **main** e **/root**.
6. Salve e aguarde alguns minutos.

## Dados já configurados
- WhatsApp: (15) 99745-7878
- E-mail: japaturvans@gmail.com
- Instagram: @japaturviagem
- Fotos reais da frota
- Logo oficial
